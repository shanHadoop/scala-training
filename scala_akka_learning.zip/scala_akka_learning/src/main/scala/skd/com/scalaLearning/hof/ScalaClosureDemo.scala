package skd.com.scalaLearning.hof

object ScalaClosureDemo extends App {

}
