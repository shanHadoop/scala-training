package skd.com.scalaLearning.day1;

import java.util.Date;

public class DateDemo {
    public static void main(String[] args) {
        System.out.println(new Date(1080193800722L));
    }
}
;