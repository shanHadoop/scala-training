package skd.com.scalaLearning.effects

object SideEffectDemo extends App{
  var incremet = 0

}
