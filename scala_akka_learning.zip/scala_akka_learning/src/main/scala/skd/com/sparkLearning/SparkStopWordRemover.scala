//package skd.com.sparkLearning
////import org.apache.spark.ml.feature.StopWordsRemover
//import org.apache.spark.ml.feature.{RegexTokenizer, Tokenizer}
//import org.apache.spark.sql.functions._
//
//class SparkStopWordRemover extends App {
//  val remover = new StopWordsRemover()
//    .setInputCol("words")
//    .setOutputCol("removed")
//    .setStopWords(Array("the", "a", "http", "i", "me", "to", "what", "in", "rt"))
//}
//
